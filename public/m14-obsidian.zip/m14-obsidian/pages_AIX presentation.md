﻿- Local LLMs via Ollama
- present: Chris, Jamie
-
- # #[[ Takeaways]]
- They told me about being organized and stuff.