﻿- The class on web development and design, taught by Douglas Cohen, through [[SUNY Polytechnic Institute]]
-