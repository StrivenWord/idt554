## Answer

The most appropriate property would be `grid-template-columns`, as referenced on [[https://developer.mozilla.org/en-US/docs/Web/CSS/grid-template-columns|MDN]].

* _Obsidian does not directly support flashcards in any special way, but it there is at least one [[https://github.com/st3v3nmw/obsidian-spaced-repetition|plugin]] that does so, apparently using the same repetition code as [[Anki]]._
* _TiddlyWiki doesn't directly feature flashcard functionality, but it can be implemented using TiddlyWiki's native widget syntax, as seen in [[https://groktiddlywiki.com/read/|Grok TiddlyWiki]], and there are multiple plugins that provide simple implementations._