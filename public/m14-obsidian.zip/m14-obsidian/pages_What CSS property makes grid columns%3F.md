﻿-
- #card grid-template-columns
  card-last-interval:: 4
  card-repeats:: 1
  card-ease-factor:: 2.36
  card-next-schedule:: 2025-02-27T04:12:59.845Z
  card-last-reviewed:: 2025-02-23T04:12:59.845Z
  card-last-score:: 3
-