﻿- find . -type f -name ".bash*" #card
	- Find all bash configuration files (ending in dot-bash) in all subdirectories of the current directory
- dpkg -l | grep ncurses #card
	- Search for all installed packages with the namespace *ncurses*. Related packages generally have a root string that is part of the name, plus prefixes or suffixes.