﻿- git branch -t main origin/main #card
	- Switch to a new local branch "main" and begin tracking origin/main. Tracking enables automatic synchronization so that the remote branch won't need to be specified in **git push** and **git pull** commands.
- git pull --rebase origin main #card
	- Download remote commits from "main" and then repeats all local commits not present in "main" in the local repository. That's what the "--rebase" parameter means; repeat, replay, overlay.