﻿- `.readFile(path, options, callback)` #card
	- Asynchronously access a file from the file system (not pausing processing or reading of the rest of the script) -- part of Node.js's File System *(fs)* module. The callback takes two arguments -- "err" and "data".
- `function ternaryOperatorTest(conditionalThing) {
          return conditionalThing ? "Yes, it is" : "No, it isn't";
  }` #card
	- Testing whether a variable, here **conditionalThing**, is true. If so, it returns the string followed by the question mark **?** character, "Yes, it is." If not, it returns the string followed by the colon character, "No, it isn't".
-